import java.util.List;

public class UserProfile {
    String name;
    int age;
    String dietaryPreference;
    private int calorieRequirement;
    private List<String> dietaryRestrictions;

    public UserProfile(String name, int age, String dietaryPreference, int calorieRequirement, List<String> dietaryRestrictions) {
        this.name = name;
        this.age = age;
        this.dietaryPreference = dietaryPreference;
        this.calorieRequirement = calorieRequirement;
        this.dietaryRestrictions = dietaryRestrictions;
    }

    public int getCalorieRequirement() {
        return calorieRequirement;
    }

    public List<String> getDietaryRestrictions() {
        return dietaryRestrictions;
    }

    public String getDietaryPreference() {
        return dietaryPreference;
    }

    public void displayProfile() {
        System.out.println("User: " + name + ", Age: " + age + ", Preference: " + dietaryPreference +
                ", Calorie Requirement: " + calorieRequirement + ", Restrictions: " + dietaryRestrictions);
    }
}