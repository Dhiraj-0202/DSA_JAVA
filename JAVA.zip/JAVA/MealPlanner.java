import java.io.*;
import java.util.*;

public class MealPlanner {
    private static List<Meal> mealDatabase = new ArrayList<>();

    static {
        loadMealsFromCSV("/Users/dhirajsolleti/Desktop/JAVA/DSA_DP-2.csv");
    }

    private static void loadMealsFromCSV(String filename) {
        try {
            File file = new File(filename);
            if (!file.exists()) {
                System.out.println("CSV file not found: " + filename);
                return;
            }
            BufferedReader reader = new BufferedReader(new FileReader(file));
            String line;
            boolean firstLine = true;

            while ((line = reader.readLine()) != null) {
                if (firstLine) {
                    firstLine = false;
                    continue; // Skip header
                }
                String[] data = line.split(";");
                try {
                    String name = data[0].trim();
                    int calories = (int) Double.parseDouble(data[1].replace(",", "."));
                    int protein = (int) Double.parseDouble(data[6].replace(",", "."));
                    int carbs = (int) Double.parseDouble(data[3].replace(",", "."));

                    // Categorize based on name/content
                    String category = categorizeMeal(name);
                    mealDatabase.add(new Meal(name, calories, protein, carbs, category));
                } catch (Exception e) {
                    System.out.println("Error parsing line: " + line);
                }
            }
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static String categorizeMeal(String name) {
        name = name.toLowerCase();
        if (name.contains("cheese") || name.contains("egg") || name.contains("milk") || 
            name.contains("butter") || name.contains("cream")) {
            return "Vegetarian";
        } else if (name.contains("chicken") || name.contains("beef") || name.contains("pork") || 
                   name.contains("ham") || name.contains("bacon") || name.contains("sausage")) {
            return "Non-Vegetarian";
        } else if (name.contains("vegan") || name.contains("tofu") || name.contains("vegetable") || 
                   name.contains("bean") || name.contains("lentil") || name.contains("salad") ||
                   name.contains("fruit") || name.contains("pasta") || name.contains("rice")) {
            return "Vegan";
        }
        return "Vegetarian"; // Default to Vegetarian if unclear
    }

    public static List<Meal> getMatchingMeals(UserProfile profile) {
        List<Meal> matchedMeals = new ArrayList<>();
        String preference = profile.getDietaryPreference();
        List<String> restrictions = profile.getDietaryRestrictions();
        int calorieLimit = profile.getCalorieRequirement() / 3; // Distribute calories across meals

        for (Meal meal : mealDatabase) {
            // Skip meals that are in the user's restrictions
            if (restrictions.contains(meal.category)) {
                continue;
            }

            // Check calorie requirement per meal
            if (meal.calories > calorieLimit) {
                continue;
            }

            // Match meals based on dietary preference
            boolean isMatch = false;
            if (preference.equals("Vegan") && meal.category.equals("Vegan")) {
                isMatch = true;
            } else if (preference.equals("Vegetarian") && 
                       (meal.category.equals("Vegan") || meal.category.equals("Vegetarian"))) {
                isMatch = true;
            } else if (preference.equals("Non-Vegetarian")) {
                isMatch = true; // Non-vegetarian can eat anything not restricted
            }

            if (isMatch) {
                matchedMeals.add(meal);
            }
        }
        return matchedMeals;
    }

    public static MealPlan generateMealPlan(UserProfile profile) {
        List<Meal> matchedMeals = getMatchingMeals(profile);
        List<Meal> breakfast = new ArrayList<>();
        List<Meal> lunch = new ArrayList<>();
        List<Meal> dinner = new ArrayList<>();
        Collections.shuffle(matchedMeals); // Randomize for variety

        for (Meal meal : matchedMeals) {
            if (breakfast.isEmpty() && meal.calories <= profile.getCalorieRequirement() / 3) {
                breakfast.add(meal);
            } else if (lunch.isEmpty() && meal.calories <= profile.getCalorieRequirement() / 3) {
                lunch.add(meal);
            } else if (dinner.isEmpty() && meal.calories <= profile.getCalorieRequirement() / 3) {
                dinner.add(meal);
            }
            if (!breakfast.isEmpty() && !lunch.isEmpty() && !dinner.isEmpty()) break;
        }

        return new MealPlan(breakfast, lunch, dinner);
    }
}