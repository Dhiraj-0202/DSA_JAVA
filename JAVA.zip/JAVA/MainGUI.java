import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import javax.swing.*;

public class MainGUI extends JFrame {
    CardLayout cardLayout = new CardLayout();
    JPanel cards = new JPanel(cardLayout);
    UserProfile currentUser;
    DietaryBST userTree = new DietaryBST();

    public MainGUI() {
        setTitle("Meal Planner");
        setSize(600, 500);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        JPanel inputPanel = createInputPanel();
        cards.add(inputPanel, "input");
        add(cards);
        setVisible(true);
    }

    private JPanel createInputPanel() {
        JPanel panel = new JPanel(new GridLayout(7, 2, 5, 5));
        JTextField nameField = new JTextField();
        JTextField ageField = new JTextField();
        JTextField calorieField = new JTextField();
        JComboBox<String> preferenceBox = new JComboBox<>(new String[]{"Vegan", "Vegetarian", "Non-Vegetarian"});

        panel.add(new JLabel("Name:")); panel.add(nameField);
        panel.add(new JLabel("Age:")); panel.add(ageField);
        panel.add(new JLabel("Calorie Requirement:")); panel.add(calorieField);
        panel.add(new JLabel("Dietary Preference:")); panel.add(preferenceBox);

        JButton nextBtn = new JButton("Next");
        panel.add(new JLabel());  // filler
        panel.add(nextBtn);

        nextBtn.addActionListener(e -> {
            try {
                String name = nameField.getText();
                int age = Integer.parseInt(ageField.getText());
                int calories = Integer.parseInt(calorieField.getText());
                String pref = (String) preferenceBox.getSelectedItem();

                List<String> restrictions = new ArrayList<>();
                if (pref.equals("Vegan")) {
                    restrictions.add("Non-Vegetarian");
                    restrictions.add("Vegetarian");
                } else if (pref.equals("Vegetarian")) {
                    restrictions.add("Non-Vegetarian");
                }

                currentUser = new UserProfile(name, age, pref, calories, restrictions);
                userTree.insert(currentUser);

                JPanel summaryPanel = createSummaryPanel();
                cards.add(summaryPanel, "summary");
                cardLayout.show(cards, "summary");
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Enter valid numbers for age and calorie.");
            }
        });

        return panel;
    }

    private JPanel createSummaryPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        JTextArea textArea = new JTextArea();
        textArea.setEditable(false);
        textArea.setText("Profile Summary:\n" +
                "Name: " + currentUser.name + "\n" +
                "Age: " + currentUser.age + "\n" +
                "Calories: " + currentUser.getCalorieRequirement() + "\n" +
                "Preference: " + currentUser.dietaryPreference + "\n" +
                "Restrictions: " + currentUser.getDietaryRestrictions());

        panel.add(new JScrollPane(textArea), BorderLayout.CENTER);

        JButton planBtn = new JButton("Generate Meal Plan");
        panel.add(planBtn, BorderLayout.SOUTH);

        planBtn.addActionListener(e -> {
            MealPlan plan = MealPlanner.generateMealPlan(currentUser);
            JPanel planPanel = createMealPlanPanel(plan);
            cards.add(planPanel, "mealPlan");
            cardLayout.show(cards, "mealPlan");
        });

        return panel;
    }

    private JPanel createMealPlanPanel(MealPlan plan) {
        JPanel panel = new JPanel(new BorderLayout());
        JTextArea area = new JTextArea();
        area.setEditable(false);
        if (plan.breakfast.isEmpty() && plan.lunch.isEmpty() && plan.dinner.isEmpty()) {
            area.append("No meals match your criteria. Try adjusting your calorie requirement or restrictions.");
        } else {
            area.append("=== Breakfast ===\n");
            plan.breakfast.forEach(m -> area.append(m + "\n"));
            area.append("\n=== Lunch ===\n");
            plan.lunch.forEach(m -> area.append(m + "\n"));
            area.append("\n=== Dinner ===\n");
            plan.dinner.forEach(m -> area.append(m + "\n"));
        }
        panel.add(new JScrollPane(area), BorderLayout.CENTER);
        return panel;
    }

    public static void main(String[] args) {
        new MainGUI();
    }
}