public class Meal {
    String name;
    int calories;
    int protein;
    int carbs;
    String category;

    public Meal(String name, int calories, int protein, int carbs, String category) {
        this.name = name;
        this.calories = calories;
        this.protein = protein;
        this.carbs = carbs;
        this.category = category;
    }

    public void displayMeal() {
        System.out.println(name + " | Calories: " + calories + " | Protein: " + protein + "g | Carbs: " + carbs + "g | Category: " + category);
    }

    
    public String toString() {
        return name + " | " + calories + " cal | " + protein + "g protein | " + carbs + "g carbs | " + category;
    }
}