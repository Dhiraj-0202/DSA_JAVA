public class DietaryBST {
    private BSTNode root;

    private static class BSTNode {
        UserProfile userProfile;
        BSTNode left, right;

        public BSTNode(UserProfile profile) {
            this.userProfile = profile;
            left = right = null;
        }
    }

    public void insert(UserProfile profile) {
        root = insertRec(root, profile);
    }

    private BSTNode insertRec(BSTNode root, UserProfile profile) {
        if (root == null) {
            return new BSTNode(profile);
        }
        if (profile.getCalorieRequirement() < root.userProfile.getCalorieRequirement()) {
            root.left = insertRec(root.left, profile);
        } else if (profile.getCalorieRequirement() > root.userProfile.getCalorieRequirement()) {
            root.right = insertRec(root.right, profile);
        }
        return root;
    }

    public void inorderTraversal() {
        inorderRec(root);
    }

    private void inorderRec(BSTNode root) {
        if (root != null) {
            inorderRec(root.left);
            root.userProfile.displayProfile();
            inorderRec(root.right);
        }
    }
}