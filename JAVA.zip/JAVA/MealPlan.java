import java.util.List;

public class MealPlan {
    List<Meal> breakfast;
    List<Meal> lunch;
    List<Meal> dinner;

    public MealPlan(List<Meal> breakfast, List<Meal> lunch, List<Meal> dinner) {
        this.breakfast = breakfast;
        this.lunch = lunch;
        this.dinner = dinner;
    }

    public void displayMealPlan() {
        System.out.println("\nMeal Plan:");
        System.out.println("Breakfast:");
        for (Meal meal : breakfast) meal.displayMeal();
        System.out.println("Lunch:");
        for (Meal meal : lunch) meal.displayMeal();
        System.out.println("Dinner:");
        for (Meal meal : dinner) meal.displayMeal();
    }
}